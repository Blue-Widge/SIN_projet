<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if (empty($_POST['dessert']) || $_POST['dessert']=="Dessert?" || !preg_match('#^[0-9]*[0-9]*$#',$_POST['stock_dessert']))
{
    header('Location: ../baseDeDonnees.php');
}
else
{
    $req=$bdd->prepare('INSERT INTO desserts(dessert, stock) VALUES(:dessert, :stock)');
    $req->execute(array(
        'dessert'=>$_POST['dessert'],
    'stock'=>$_POST['stock_dessert']));
    $req->closeCursor();
    header('Location: ../baseDeDonnees.php');
}




?>