<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if (empty($_POST['entree']) || $_POST['entree']=="Entrée?" || !preg_match('#^[0-9]*[0-9]*$#',$_POST['stock_entree']))
{
    header('Location: ../baseDeDonnees.php');
}
else
{
    $req=$bdd->prepare('INSERT INTO entrées(entrée, stock) VALUES(:entree, :stock)');
    $req->execute(array(
        'entree'=>$_POST['entree'],
    'stock'=>$_POST['stock_entree']));
    $req->closeCursor();
    header('Location: ../baseDeDonnees.php');
}




?>