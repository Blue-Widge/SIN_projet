<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if (empty($_POST['fromage']) || $_POST['fromage']=="Fromage?" || !preg_match('#^[0-9]*[0-9]*$#',$_POST['stock_fromage']))
{
    header('Location: ../baseDeDonnees.php');
}
else
{
    $req=$bdd->prepare('INSERT INTO fromages(fromage, stock) VALUES(:fromage, :stock)');
    $req->execute(array(
        'fromage'=>$_POST['fromage'],
    'stock'=>$_POST['stock_fromage']));
    $req->closeCursor();
    header('Location: ../baseDeDonnees.php');
}




?>