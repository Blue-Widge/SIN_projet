﻿<?php
    session_start();
	include('identification.php');
	
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
?>
<?php 
    $req=$bdd->query('SELECT * FROM Lundi');
    $donnees=$req->fetch();
    $req->closeCursor();
    $entreeLundi=$donnees['entrées']; $platLundi=$donnees['plats']; $dessertLundi=$donnees['desserts'];
    
    $req=$bdd->query('SELECT * FROM Mardi');
    $donnees=$req->fetch();
    $req->closeCursor();
    $entreeMardi=$donnees['entrées']; $platMardi=$donnees['plats']; $dessertMardi=$donnees['desserts'];
    
    $req=$bdd->query('SELECT * FROM Mercredi');
    $donnees=$req->fetch();
    $req->closeCursor();
    $entreeMercredi=$donnees['entrées']; $platMercredi=$donnees['plats']; $dessertMercredi=$donnees['desserts'];
    
    $req=$bdd->query('SELECT * FROM Jeudi');
    $donnees=$req->fetch();
    $req->closeCursor();
    $entreeJeudi=$donnees['entrées']; $platJeudi=$donnees['plats']; $dessertJeudi=$donnees['desserts'];
    
    $req=$bdd->query('SELECT * FROM Vendredi');
    $donnees=$req->fetch();
    $req->closeCursor();
    $entreeVendredi=$donnees['entrées']; $platVendredi=$donnees['plats']; $dessertVendredi=$donnees['desserts'];
;?>



<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<link rel="Stylesheet" href="style.css" class="rel"/>
	<title>Restaurant scolaire lycée Réaumur et Buron</title>
	<link rel="icon" href="assets/favicon.ico" />
</head>

<body>
<!---------------------------HEADER-------------------------------->
	<header> 
		<div style="margin-top:1%; margin-bottom:1%;">
			<img src="assets/haut.PNG" 	   alt="header"    width="30%">
			<img src="assets/logoPdlL.png" alt="logo PdlL" width="15%" style="float:right">
		</div>

		<nav>
			<ul>
				<li>RESTAURANT SCOLAIRE</li>
				
				<li> 					
					<img id="tdb" src="assets/icone_tdb.png" alt="iconeTdB" width="30vw">					
						<a href="#tableauDeBord">TABLEAU DE BORD</a>
				</li>
				
				
				<li>				
					<img id="menus" src="assets/icone_menu1.png" alt="iconeMenu" width="30vw">					
					<a href="#menu">MENUS</a>
				</li>		
			    
			    <?php // SI INTENDANT ALORS AFFICHAGE ONGLET "STOCK" 
					if (isset($_SESSION['id']))
					{?>
					<li><a href="baseDeDonnees.php" style="text-align:center;margin:auto">Base de données </a>
					<p style="font-size:1.5vw; margin:auto"> Bien le bonjour, <strong style="color:red;"> intendant(e) </strong> ! <a style="font-size:1vw; color:white; text-decoration: underline;" href="deconnexion.php">Se deconnecter</a></p> </li>
					<?php
					}
					else
					{
						?> <form action="Accueil.php" method="post" style="float:right; height:50px; font-size:14px; margin-top:3px;">
								<label style="font-size:1.2vw">Identifiant :</label> <input type="text" name="username" id="identifiant" style="margin-left:1.2vw; width:10vw; font-size:1vw; height:2.5vh"/>
								</br>
								<label for="pass" style="font-size:1.2vw; float:left;">Mot de passe :</label> <input type="password" name="password" id="pass" style="width:10vw; font-size:1vw; height:2.5vh" />	
								<input type="submit" value="Se connecter" style="width:6vw; font-size:0.8vw; float:right"/>
							</form>
						<?php
					}
					?>
			</ul>
		</nav>					
	</header>	
<!---------------------------TABLEAU DE BORD-------------------------------->
	<div id="tableauDeBord">
		<h2> TABLEAU DE BORD</h2>
		
		<div id="container"> 
			<div class="element">Flux d'entrée			 
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Flux de sortie
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Actuel   
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Repas chauds           
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Emballage Poub.1		
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Emballage Poub.2
				<div class="data-container">XXX</div>
			</div>
		
			<div class="element">Emballage Poub.3
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Poubelle pains
				<div class="data-container">XXX</div>
			</div>
			
		</div>
		
		<div id="graphique">	</div>
		
		<div id="container1">
			<div class="element">Rempl. poubelle 1
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Rempl. poubelle 2
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Rempl. poubelle 3
				<div class="data-container">XXX</div>
			</div>
			
			<div class="element">Remplissage pains
				<div class="data-container">XXX</div>
			</div>
		
		</div>
	
	</div>
	
<!---------------------------MENUS-------------------------------->
	<div id="menu">
		<h2>Menu</h2>
		<?php
	                	//MODIFICATION DU MENU
		    if (isset($_POST['modifMenu']) || isset($_SESSION['modif']) && $_SESSION['modif']==true)
		    {
		        $_SESSION['modif']=true;
		    ?>
		    <div>
	    	    <form action="menuModif.php" method="post">
		            <input type="text" name="annuler" style="width:0; visibility:hidden;"/>
		            <input type="submit" value="Annuler"/>
		        </form>
		        <form action="menuModif.php" method="post">
		            <input type="submit" value="Accepter"/>
		        
		    </div>
		        <div id="menuContainer">
			
			<table>
				<thead>

					<tr>
						<th id="vide"></th>
						<th>Entrée</th>
						<th>Plats</th>
						<th>Dessert</th>
					</tr>
				</thead>
				<?php $regReplace=array('#<br />#','#<br/>#','#\n#'); ?>
				<tr>
					<th>Lundi</th>
						<td><textarea name="entréeLundi"><?php echo preg_replace($regReplace,NULL,$entreeLundi) ?></textarea></td>
						<td><textarea name="platLundi"><?php echo preg_replace($regReplace,NULL,$platLundi) ?> </textarea></td>
						<td><textarea name="dessertLundi"><?php echo preg_replace($regReplace,NULL,$dessertLundi)?></textarea></td>						
				</tr>
				<tr>
				
					<th>Mardi</th>
						<td><textarea name="entréeMardi"><?php echo preg_replace($regReplace,NULL,$entreeMardi) ?></textarea></td>
						<td><textarea name="platMardi" ><?php echo preg_replace($regReplace,NULL,$platMardi) ?></textarea></td>
						<td><textarea name="dessertMardi"><?php echo preg_replace($regReplace,NULL,$dessertMardi)?></textarea></td>	
				</tr>
				<tr>	
					<th>Mercredi</th>
						<td><textarea name="entréeMercredi"><?php echo preg_replace($regReplace,NULL,$entreeMercredi) ?></textarea></td>
						<td><textarea name="platMercredi"><?php echo preg_replace($regReplace,NULL,$platMercredi) ?></textarea></td>
						<td><textarea name="dessertMercredi"><?php echo preg_replace($regReplace,NULL,$dessertMercredi)?></textarea></td>	
				</tr>
				<tr>
					<th>Jeudi</th>
						<td><textarea name="entréeJeudi"><?php echo preg_replace($regReplace,"",$entreeJeudi) ?></textarea></td>
						<td><textarea name="platJeudi" ><?php echo preg_replace($regReplace,"\n",$platJeudi) ?></textarea></td>
						<td><textarea name="dessertJeudi"><?php echo preg_replace($regReplace,"\n",$dessertJeudi) ?></textarea></td>	
				</tr>
				<tr>
					<th>Vendredi</th>
						<td><textarea name="entréeVendredi"><?php echo preg_replace($regReplace,"\n",$entreeVendredi) ?></textarea></td>
						<td><textarea name="platVendredi"><?php echo preg_replace($regReplace,"\n",$platVendredi) ?></textarea></td>
						<td><textarea name="dessertVendredi"><?php echo preg_replace($regReplace,"\n",$dessertVendredi)?></textarea></td>	
						
				</tr>
			</table>
			</form>
			<style>
			    textarea
			    {
			       width:99%; 
			       height:99%; 
			       resize:none;
			       background-color:grey; 
			       border:none; padding:0; 
			       cursor: url(assets/whiteCursor.png), s-resize;
			    }
			</style>
			<?php
		        
		    }
		                //AFFICHAGE DU MENU
		    else
		    {
		        if (isset($_SESSION['id']))
		        {?>
		        <form action="Accueil.php" method="post">
		            <input type="text" name="modifMenu" style="width:0; visibility:hidden;"/>
		            <input id="ModifMenu" type="submit" value="Modifier"/>
	        	</form> <?php } ?>
		
		<div id="menuContainer">
			
			<table>
				<thead>

					<tr>
						<th id="vide"></th>
						<th>Entrée</th>
						<th>Plats</th>
						<th>Dessert</th>
					</tr>
				</thead>


				<tr>
					<th>Lundi</th>
						<td><?php echo $entreeLundi ?></td>
						<td> <?php echo $platLundi ?></td>
						<td><?php echo $dessertLundi ?></td>						
				</tr>
	
				<tr>
				
					<th>Mardi</th>
						<td><?php echo $entreeMardi ?></td>
						<td> <?php echo $platMardi ?></td>
						<td><?php echo $dessertMardi ?></td>
				</tr>
				<tr>	
					<th>Mercredi</th>
						<td><?php echo $entreeMercredi ?></td>
						<td> <?php echo $platMercredi ?></td>
						<td><?php echo $dessertMercredi ?></td>
				</tr>
				<tr>
					<th>Jeudi</th>
						<td><?php echo $entreeJeudi?></td>
						<td> <?php echo $platJeudi ?></td>
						<td><?php echo $dessertJeudi ?></td>
				</tr>
				<tr>
					<th>Vendredi</th>
						<td><?php echo $entreeVendredi ?></td>
						<td> <?php echo $platVendredi ?></td>
						<td><?php echo $dessertVendredi ?></td>
						
				</tr>
			</table>
			<?php
		    }
		    ?>
		</div>
	</div>

</body>

</html>
<style>
body
{
	font-family:"Segoe UI";

}
header
{
	
}
nav
{
	margin:2% auto 0 auto;
	width:95%;
	border: 1px blue dashed;
	background-color:#662f90;
	color:white;

}
ul
{
	display:flex;
	justify-content:space-around;
	list-style-type:none;
	font-weight:bold;
	font-size:1.6vw;
	padding:0;
}
li
{
	margin:auto;
	text-align:center;
}
a
{
	text-decoration:none;
	color:white;
}


/* -----------------------------------------Tableau De Bord ---------------------------*/


#tableauDeBord
{
	margin:5% 10% auto 10%;
	border:9px #662f90 solid;
}
h2
{
	margin-left:5%;
	color:#662f90;
	font-size:3vw;
	text-decoration:underline;
	font-weight:bold;
}

#container,#container1
{
	display:grid;
	 grid-template-columns: 1fr 1fr 1fr 1fr;
	margin:auto;
	width:90%;
	color:black;
	text-align:center;
	font-size:1.5vw;
}
.element
{
	min-width:20%;
	border:4px black solid;
	margin:3% 5%;
}
.data-container
{
	border:3px black solid;
	background-color:rgb(128,128,128);
	margin:2% auto;
	width:92%;
}

#graphique
{
	max-width:80%;
	height:40vh;
	margin:5% auto;
	border:3px black solid;
	background-color:rgb(128,128,128);
}

/*-----------------------------------------MENUS----------------------------------------->*/

#menu
{
	margin:5% 10% auto 10%;
	border:7px #662f90 solid;
}

#menu input[type=submit]
{
    border:3px #662f90 solid;
    background-color:grey;
    font-weight:900;
    margin:10px auto auto 25%;
    cursor:pointer;
    font-size:1.5vw;
}
#menuContainer{
	width:80%;
	height:70vh;
	border:3px black solid;
	margin:2% auto;
	background:#808080;	
}

table{
	border-collapse: collapse;
	max-width:100%;
	min-width:100%;
	height:100%;
	color:black;
	text-align:center;
	font-size:3.5vh;
}

td, th
{
    border: 2px solid black;
}
td{
    width:25%;
	font-size:1vw;
	word-break: break-word;
}

#vide{
	background-color:black;
}
</style>