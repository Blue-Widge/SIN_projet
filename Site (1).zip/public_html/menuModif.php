<?php
session_start();
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}


if (isset($_POST['annuler']))
{
    $_SESSION['modif']=false;
    header('Location: Accueil.php');
}
else
{
    //                              LUNDI
    if (isset($_POST['entréeLundi']) && !empty($_POST['entréeLundi']))
    {
        $query=$bdd->prepare('UPDATE Lundi SET entrées=?');
        $query->execute(array(nl2br($_POST['entréeLundi'])));
    }
    if (isset($_POST['platLundi']) && !empty($_POST['platLundi']))
    {
        $query=$bdd->prepare('UPDATE Lundi SET plats=?');
        $query->execute(array(nl2br($_POST['platLundi'])));
    }
    if (isset($_POST['dessertLundi']) && !empty($_POST['dessertLundi']))
    {
        $query=$bdd->prepare('UPDATE Lundi SET desserts=?');
        $query->execute(array(nl2br($_POST['dessertLundi'])));
    }
    
    //                              MARDI
    
    if (isset($_POST['entréeMardi']) && !empty($_POST['entréeMardi']))
    {
        $query=$bdd->prepare('UPDATE Mardi SET entrées=?');
        $query->execute(array(nl2br($_POST['entréeMardi'])));
    }
    if (isset($_POST['platMardi']) && !empty($_POST['platMardi']))
    {
        $query=$bdd->prepare('UPDATE Mardi SET plats=?');
        $query->execute(array(nl2br($_POST['platMardi'])));
    }
    if (isset($_POST['dessertMardi']) && !empty($_POST['dessertMardi']))
    {
        $query=$bdd->prepare('UPDATE Mardi SET desserts=?');
        $query->execute(array(nl2br($_POST['dessertMardi'])));
    }
    
    //                              MERCREDI
    
    if (isset($_POST['entréeMercredi']) && !empty($_POST['entréeMercredi']))
    {
        $query=$bdd->prepare('UPDATE Mercredi SET entrées=?');
        $query->execute(array(nl2br($_POST['entréeMercredi'])));
    }
    if (isset($_POST['platMercredi']) && !empty($_POST['platMercredi']))
    {
        $query=$bdd->prepare('UPDATE Mercredi SET plats=?');
        $query->execute(array(nl2br($_POST['platMercredi'])));
    }
    if (isset($_POST['dessertMercredi']) && !empty($_POST['dessertMercredi']))
    {
        $query=$bdd->prepare('UPDATE Mercredi SET desserts=?');
        $query->execute(array(nl2br($_POST['dessertMercredi'])));
    }
    
    //                              JEUDI
    
    if (isset($_POST['entréeJeudi']) && !empty($_POST['entréeJeudi']))
    {
        $query=$bdd->prepare('UPDATE Jeudi SET entrées=?');
        $query->execute(array(nl2br($_POST['entréeJeudi'])));
    }
    if (isset($_POST['platJeudi']) && !empty($_POST['platJeudi']))
    {
        $query=$bdd->prepare('UPDATE Jeudi SET plats=?');
        $query->execute(array(nl2br($_POST['platJeudi'])));
    }
    if (isset($_POST['dessertJeudi']) && !empty($_POST['dessertJeudi']))
    {
        $query=$bdd->prepare('UPDATE Jeudi SET desserts=?');
        $query->execute(array(nl2br($_POST['dessertJeudi'])));
    }
    
    //                              VENDREDI
    
    if (isset($_POST['entréeVendredi']) && !empty($_POST['entréeVendredi']))
    {
        $query=$bdd->prepare('UPDATE Vendredi SET entrées=?');
        $query->execute(array(nl2br($_POST['entréeVendredi'])));
    }
    if (isset($_POST['platVendredi']) && !empty($_POST['platVendredi']))
    {
        $query=$bdd->prepare('UPDATE Vendredi SET plats=?');
        $query->execute(array(nl2br($_POST['platVendredi'])));
    }
    if (isset($_POST['dessertVendredi']) && !empty($_POST['dessertVendredi']))
    {
        $query=$bdd->prepare('UPDATE Vendredi SET desserts=?');
        $query->execute(array(nl2br($_POST['dessertVendredi'])));
    }
    $_SESSION['modif']=false;
    header('Location: Accueil.php');
}

?>