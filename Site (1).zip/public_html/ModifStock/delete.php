<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}



if (isset($_POST['Quoi']))
{
    $quoi = $_POST['Quoi'];
    if ($quoi[0]=='e')
    {
        //ENTREE
        $id=preg_replace('#[a-z]#',"",$quoi);;
        $req=$bdd->prepare('DELETE FROM entrées WHERE id=?');
        $req->execute(array($id));
        $req->closeCursor();
        header('Location: ../baseDeDonnees.php');
    }
    else if ($quoi[0]=='p')
    {
        //PLAT
        $id=preg_replace('#[a-z]#',"",$quoi);
        $req=$bdd->prepare('DELETE FROM plats WHERE id=?');
        $req->execute(array($id));
        $req->closeCursor();
        header('Location: ../baseDeDonnees.php');
    }
    else if ($quoi[0]=='f')
    {
        //FROMAGES
        $id=preg_replace('#[a-z]#',"",$quoi);
        $req=$bdd->prepare('DELETE FROM fromages WHERE id=?');
        $req->execute(array($id));
        $req->closeCursor();
        header('Location: ../baseDeDonnees.php');
    }
    else if ($quoi[0]=='d')
    {
        //DESSERTS
        $id=preg_replace('#[a-z]#',"",$quoi);
        $req=$bdd->prepare('DELETE FROM desserts WHERE id=?');
        $req->execute(array($id));
        $req->closeCursor();
        header('Location: ../baseDeDonnees.php');
    }
    else
    {
        header('Location: ../baseDeDonnees.php');
    }
}
else
{
    header('Location: ../baseDeDonnees.php');
}
?>