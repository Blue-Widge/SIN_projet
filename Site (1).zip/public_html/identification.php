
<!-- CONNEXION A LA BASE DE DONNEES MYSQL -->
<?php 
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=id12795532_projet;charset=utf8', 'id12795532_root','PROJET');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
?>

<?php
	if (isset($_POST['username']) AND !empty(isset($_POST['username'])) AND isset($_POST['password']) AND !empty($_POST['password']))
	{		
		$req=$bdd->query('SELECT * FROM identification');
		$donnees=$req->fetch();
		$req->closeCursor();
		if ($donnees['username']==$_POST['username'] AND $donnees['password']==$_POST['password'])
		{
			$_SESSION['username']=$donnees['username'];
			$_SESSION['id']=$donnees['id'];
		}
		else
		{
			//USERNAME OU MOT DE PASSE INCORRECT
		}
	}

?>